#include<iostream>
using namespace std;

bool linearSearch(int *arr,int size, int target){
    for(int i=0;i<size;i++){
        if(arr[i]==target){
            return true;
        }
        break;
    }
    return false;
}

int main(){
    int size;
    cout<<"Enter Size of Array: ";
    cin>>size;
     int *arr=new int[size];
     cout<<"Enter Array Elements: "<<endl;
    for(int i=0;i<size;i++){
        cin>>arr[i];
    }
    int target;
    cout<<"Enter the Target Value to search: ";
    cin>>target;
    linearSearch(arr,size,target);


}